﻿using System;
using System.IO;
using System.Reflection;

namespace XamarinByExample.Chapter2.TranslatorShared
{
    public static class Extensions
    {
        /// <summary>
        /// Translate the specified key in the language dependent value.
        /// </summary>
        /// <param name="key">Key to translate.</param>
        public static string Translate(this string key)
        {
            //gets the assembly where this code is compiled
            var assembly = Assembly.GetExecutingAssembly();

            //extracts the namespace of the embedded resource (platform specific) 
            var ns = assembly.FullName.Split(new char[] { ',' }, 2)[0];

            //build the name of the resource using the extracted namespace
            var resourceName = String.Format("{0}.default.csv", ns);

            //define the separator of the csv file
            const char separator = ',';

            //assigns the key to the value
            var value = key;

            // using disposes the objects for us
            using (var stream = assembly.GetManifestResourceStream(resourceName))
            {
                using (var reader = new StreamReader(stream))
                {
                    //read the file till the end and save it in a variable called result
                    var result = reader.ReadToEnd();

                    //build an array where each element is a row of the file
                    var lines = result.Split('\n');

                    //iterate until the value has not been replaced
                    //or the file has been read till the end.
                    //To put the condition inside the statement of the cycle
                    //allows us to avoid writing a redundant "if" statements inside the cycle
                    for (var i = 0; i < lines.Length && value == key; i++)
                    {
                        //separate the key from the values using the separator.
                        var keyValues = result.Split(new char[] { separator }, 2);

                        // this is a ternary operator (info box)
                        value = (keyValues[0] == key) ? keyValues[1] : key;
                    }
                }
            }

            //returns the value that is the same as the key if nothing has been found
            return value;
        }
    }
}