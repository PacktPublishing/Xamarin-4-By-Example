﻿using System;
using XamarinByExample.Chapter2.TranslatorShared;

namespace Test
{
	public class MainClass
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!".Translate());

			Console.ReadLine();
		}
	}
}
