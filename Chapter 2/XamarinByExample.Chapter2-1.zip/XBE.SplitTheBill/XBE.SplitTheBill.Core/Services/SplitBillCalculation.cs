﻿using System;

namespace XBE.SplitTheBill.Core
{
	public class SplitBillCalculation : ISplitBillCalculation
	{
		public SplitBillCalculation()
		{
		}

		public double AmountPerPerson(double totalBill, int numberOfPeople, int percentageOfTip)
		{
			return ((totalBill) * ((double)percentageOfTip / 100) / numberOfPeople);
		}
	}
}
